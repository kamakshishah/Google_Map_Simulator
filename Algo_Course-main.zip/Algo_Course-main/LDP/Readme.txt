Readme
This document provides an in depth explanation on how to successfully run Team - A's Loading Data Program(LDP)

Steps:
- Launch onlinegdb using https://www.onlinegdb.com
- Select Java as language using dropdown menu at top right corner of the website
- Upload LDPtxt.java file using the upload button. Located next to new file button at top left 
  corner of the website
- Upload CityData.java file using the upload button
- Upload RouteData.java file using the upload button
- Copy paste Dataset-1 from MyDatasets.txt into notepad, Save notepad file in the following         
  format "membername_statename_Cities.txt"
- Copy paste Dataset-2 from MyDatasets.txt into notepad, Save notepad file in the following  
  format "membername_statename_Weather.txt"
- Upload file "membername_statename_Cities.txt" to onlinegdb using the upload button
- Upload file "membername_statename_Weather.txt" to onlinegdb using the upload button
- Run the program using the run button, located next to upload button
